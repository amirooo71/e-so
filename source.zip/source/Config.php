<?php

namespace ErfanBot;

use Longman\TelegramBot\Telegram;

require __DIR__ . '/vendor/autoload.php';

require_once './parameters.php';

$telegram = new Telegram($token, $username);
$telegram->enableMySql($mysql_credentials);
// $telegram->enableAdmins(****************************);
$telegram->addCommandsPath(__DIR__ . "/Command");
