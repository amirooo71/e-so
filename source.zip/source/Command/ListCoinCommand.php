<?php
/**
 * This file is part of the TelegramBot package.
 *
 * (c) Avtandil Kikabidze aka LONGMAN <akalongman@gmail.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Longman\TelegramBot\Commands\AdminCommands;

use Longman\TelegramBot\Commands\AdminCommand;
use Longman\TelegramBot\DB;
use Longman\TelegramBot\Request;

/**
 * Class SettingCommand
 * @package Longman\TelegramBot\Commands\AdminCommands
 */
class ListCoinCommand extends AdminCommand
{
    /**
     * @var string
     */
    protected $name = 'listcoin';

    /**
     * @var string
     */
    protected $description = 'Get all coins';

    /**
     * @var string
     */
    protected $usage = '/listcoin';

    /**
     * @var string
     */
    protected $version = '1.4.0';

    /**
     * @var bool
     */
    protected $need_mysql = true;

    /**
     * @return \Longman\TelegramBot\Entities\ServerResponse
     * @throws \Longman\TelegramBot\Exception\TelegramException
     */
    public function execute()
    {
        $message = $this->getMessage();
        $chat = $message->getChat();
        $chat_id = $chat->getId();

        $data = [
            "chat_id" => $chat_id,
            "text" => $this->getMsg()
        ];
        return Request::sendMessage($data);
    }

    private function getMsg()
    {
        $coins = $this->getCoins();
        if ($coins !== null) {
            $text = "لیست ارزها" . PHP_EOL . PHP_EOL;
            foreach ($coins as $c) {
                $text .= $c['name'] . "پاک کردن :" . " /del_" . $c['name'] . PHP_EOL;;
            }
        } else {
            $text = "ارزی موجود نیست";
        }
        return $text;
    }

    /**
     * @return array|null
     */
    private function getCoins()
    {
        $pdo = DB::getPdo();
        $statment = $pdo->prepare("SELECT * FROM coins");
        $statment->execute();
        if ($statment->rowCount() == 0) {
            return null;
        }
        return $statment->fetchAll(\PDO::FETCH_ASSOC);

    }

}
