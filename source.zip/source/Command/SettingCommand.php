<?php
/**
 * This file is part of the TelegramBot package.
 *
 * (c) Avtandil Kikabidze aka LONGMAN <akalongman@gmail.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Longman\TelegramBot\Commands\AdminCommands;

use Longman\TelegramBot\Commands\AdminCommand;
use Longman\TelegramBot\Conversation;
use Longman\TelegramBot\DB;
use Longman\TelegramBot\Entities\Keyboard;
use Longman\TelegramBot\Request;

/**
 * Class SettingCommand
 * @package Longman\TelegramBot\Commands\AdminCommands
 */
class SettingCommand extends AdminCommand
{
    /**
     * @var string
     */
    protected $name = 'setting';

    /**
     * @var string
     */
    protected $description = 'Blockchain price setting for admin';

    /**
     * @var string
     */
    protected $usage = '/setting';

    /**
     * @var string
     */
    protected $version = '1.4.0';

    /**
     * @var bool
     */
    protected $need_mysql = true;

    /**
     * @var bool
     */
    protected $private_only = true;
    /**
     * Conversation Object
     *
     * @var \Longman\TelegramBot\Conversation
     */
    protected $conversation;

    /**
     * Execute command
     *
     * @return \Longman\TelegramBot\Entities\ServerResponse
     * @throws \Longman\TelegramBot\Exception\TelegramException
     */
    public function execute()
    {
        $message = $this->getMessage();
        $chat = $message->getChat();
        $user = $message->getFrom();
        $text = trim($message->getText(true));
        $chat_id = $chat->getId();
        $user_id = $user->getId();
        //Preparing Response
        $data = [
            'chat_id' => $chat_id,
        ];
        if ($chat->isGroupChat() || $chat->isSuperGroup()) {
            //reply to message id is applied by default
            //Force reply is applied by default so it can work with privacy on
            $data['reply_markup'] = Keyboard::forceReply(['selective' => true]);
        }
        //Conversation start
        $this->conversation = new Conversation($user_id, $chat_id, $this->getName());
        $notes = &$this->conversation->notes;
        !is_array($notes) && $notes = [];
        //cache data from the tracking session if any
        $state = 0;
        if (isset($notes['state'])) {
            $state = $notes['state'];
        }
        $result = Request::emptyResponse();
        //State machine
        //Entrypoint of the machine state if given by the track
        //Every time a step is achieved the track is updated
        switch ($state) {
            case 0:
                if ($text === '' || !is_numeric($text)) {
                    $notes['state'] = 0;
                    $this->conversation->update();
                    $data['text'] = 'قیمت دلار را وارد کنید';
                    if ($text !== '') {
                        $data['text'] = '❌ لطفا عدد وارد کنید';
                    }
                    $data['reply_markup'] = Keyboard::remove(['selective' => true]);
                    $result = Request::sendMessage($data);
                    break;
                }
                $notes['dollarPrice'] = $text;
                $text = '';
            // no break
            case 1:
                if ($text === '' || !is_numeric($text)) {
                    $notes['state'] = 1;
                    $this->conversation->update();
                    $data['text'] = 'درصد سود فروش را وارد کنید:';
                    if ($text !== '') {
                        $data['text'] = '❌ لطفا عدد وارد کنید';
                    }
                    $result = Request::sendMessage($data);
                    break;
                }
                $notes['saleProfitPercent'] = $text;
                $text = '';
            // no break
            case 2:
                if ($text === '' || !is_numeric($text)) {
                    $notes['state'] = 2;
                    $this->conversation->update();
                    $data['text'] = 'سود ثابت فروش را وارد کنید:';
                    if ($text !== '') {
                        $data['text'] = '❌ لطفا عدد وارد کنید';
                    }
                    $result = Request::sendMessage($data);
                    break;
                }
                $notes['saleStablePercent'] = $text;
                $text = '';
            // no break
            case 3:
                if ($text === '' || !is_numeric($text)) {
                    $notes['state'] = 3;
                    $this->conversation->update();
                    $data['text'] = 'درصد سود خرید را وارد کنید:';
                    if ($text !== '') {
                        $data['text'] = '❌ لطفا عدد وارد کنید';
                    }
                    $result = Request::sendMessage($data);
                    break;
                }
                $notes['buyProfitPercent'] = $text;
                $text = '';
            case 4:
                if ($text === '' || !is_numeric($text)) {
                    $notes['state'] = 4;
                    $this->conversation->update();
                    $data['text'] = 'سود ثابت خرید را وارد کنید:';
                    if ($text !== '') {
                        $data['text'] = '❌ لطفا عدد وارد کنید';
                    }
                    $result = Request::sendMessage($data);
                    break;
                }
                $notes['buyStablePercent'] = $text;
                $text = '';
            // no break
            case 5:
                if ($text === '' || !is_numeric($text)) {
                    $notes['state'] = 5;
                    $this->conversation->update();
                    $data['text'] = 'قیمت پیش فرض بیتکوین در صورت قطع شدن ارتباط با سرور:';
                    if ($text !== '') {
                        $data['text'] = '❌ لطفا عدد وارد کنید';
                    }
                    $result = Request::sendMessage($data);
                    break;
                }
                $notes['dPriceBitcoin'] = $text;
            case 6:
                $this->conversation->update();
                $this->setSetting($notes['dollarPrice'], $notes['saleProfitPercent'], $notes['saleStablePercent'], $notes['buyProfitPercent'], $notes['buyStablePercent'], $notes['dPriceBitcoin']);
                $text = 'اطلاعات با موفقیت ذخیره شد.' . PHP_EOL;
                $text .= 'اطلاعات وارد شده :' . PHP_EOL;
                $text .= "قیمت دلار :" . $notes['dollarPrice'] . PHP_EOL;
                $text .= "درصد سود فروش :" . $notes['saleProfitPercent'] . PHP_EOL;
                $text .= "سود ثابت فروش :" . $notes['saleStablePercent'] . PHP_EOL;
                $text .= "درصد سود خرید :" . $notes['buyProfitPercent'] . PHP_EOL;
                $text .= "سود ثابت خرید :" . $notes['buyStablePercent'] . PHP_EOL;
                $text .= "قیمت پیش فرض بیتکوین :" . $notes['dPriceBitcoin'] . PHP_EOL;
                $data['text'] = $text;
                $data['reply_markup'] = Keyboard::remove(['selective' => true]);
                $this->conversation->stop();
                $result = Request::sendMessage($data);
                break;
        }
        return $result;
    }

    private function setSetting($dPrice, $spPrice, $ssPrice, $bpPrice, $bsPrice, $dPriceB)
    {
        $pdo = DB::getPdo();
        $statment = $pdo->prepare("UPDATE alert_setting SET dollar_price=$dPrice, sale_profit_percent=$spPrice, sale_profit_stable=$ssPrice,buy_profit_percent=$bpPrice,buy_profit_stable=$bsPrice,dprice_bitcoin=$dPriceB");
        $statment->execute();
    }
}
