<?php
/**
 * This file is part of the TelegramBot package.
 *
 * (c) Avtandil Kikabidze aka LONGMAN <akalongman@gmail.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Longman\TelegramBot\Commands\AdminCommands;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use Longman\TelegramBot\Commands\AdminCommand;
use Longman\TelegramBot\Conversation;
use Longman\TelegramBot\Entities\Keyboard;
use Longman\TelegramBot\Request;
use Longman\TelegramBot\DB;

/**
 * Class CoinCommand
 * @package Longman\TelegramBot\Commands\UserCommands
 */
class CoinCommand extends AdminCommand
{
    /**
     * @var string
     */
    protected $name = 'coin';
    /**
     * @var string
     */
    protected $description = 'وارد کردن ارز جدید';
    /**
     * @var string
     */
    protected $usage = '/coin';
    /**
     * @var string
     */
    protected $version = '0.3.0';
    /**
     * @var bool
     */
    protected $need_mysql = true;
    /**
     * @var bool
     */
    protected $private_only = true;
    /**
     * Conversation Object
     *
     * @var \Longman\TelegramBot\Conversation
     */
    protected $conversation;

    /**
     * Command execute method
     *
     * @return \Longman\TelegramBot\Entities\ServerResponse
     * @throws \Longman\TelegramBot\Exception\TelegramException
     */
    public function execute()
    {
        $message = $this->getMessage();
        $chat = $message->getChat();
        $user = $message->getFrom();
        $text = trim($message->getText(true));
        $chat_id = $chat->getId();
        $user_id = $user->getId();
        //Preparing Response
        $data = [
            'chat_id' => $chat_id,
        ];

        if ($chat->isGroupChat() || $chat->isSuperGroup()) {
            //reply to message id is applied by default
            //Force reply is applied by default so it can work with privacy on
            $data['reply_markup'] = Keyboard::forceReply(['selective' => true]);
        }
        //Conversation start
        $this->conversation = new Conversation($user_id, $chat_id, $this->getName());
        $notes = &$this->conversation->notes;
        !is_array($notes) && $notes = [];
        //cache data from the tracking session if any
        $state = 0;
        if (isset($notes['state'])) {
            $state = $notes['state'];
        }
        $result = Request::emptyResponse();
        //State machine
        //Entrypoint of the machine state if given by the track
        //Every time a step is achieved the track is updated
        switch ($state) {
            case 0:
                if ($text === '') {
                    $notes['state'] = 0;
                    $this->conversation->update();
                    $data['text'] = 'نام ارز جدید را وارد کنید:';
                    $result = Request::sendMessage($data);
                    break;
                }
                if ($this->getCoinDetail($text) == null) {
                    $data['text'] = 'ارز معتبر نیست';
                    Request::sendMessage($data);
                    break;
                } else {
                    $notes['coin'] = $text;
                }
            // no break
            case 1:
                $this->conversation->update();
                $this->saveCoin($notes['coin']);
                $text = 'ارز با موفقیت وارد شد.' . PHP_EOL;
                $text .= 'وارد کردن ارز جدید' . " /coin " . PHP_EOL;
                $text .= "لیست ارزها :" . PHP_EOL;
                foreach ($this->getCoinsList() as $c) {
                    $text .= $c['name'] . "پاک کردن :" . " /del_" . $c['name'] . PHP_EOL;
                }
                $data['text'] = $text;
                $this->conversation->stop();
                $result = Request::sendMessage($data);
                break;
        }
        return $result;
    }

    private function saveCoin($coin)
    {
        $pdo = DB::getPdo();
        $statment = $pdo->prepare("INSERT INTO coins SET name=?");
        $statment->execute([$coin]);
    }

    private function getCoinDetail($coinName)
    {
        try {
            $client = new Client();
            $res = $client->request('GET', "****************");
            $coinDetailAsJson = $res->getBody();
            $coinDetail = \GuzzleHttp\json_decode($coinDetailAsJson, true);
            return $coinDetail;
        } catch (ClientException $e) {
            echo 'Caught response: ' . $e->getResponse()->getStatusCode();
        }
    }

    /**
     * @return array|null
     */
    private function getCoinsList()
    {
        $pdo = DB::getPdo();
        $statment = $pdo->prepare("SELECT * FROM coins");
        $statment->execute();
        if ($statment->rowCount() == 0) {
            return null;
        }
        return $statment->fetchAll(\PDO::FETCH_ASSOC);
    }

}
