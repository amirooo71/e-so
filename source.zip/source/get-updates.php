<?php
require './Config.php';

try {
    $telegram->enableLimiter();
    $serverResponse = $telegram->handleGetUpdates();

    if ($serverResponse->isOk()) {
        $updateCount = count($serverResponse->getResult());
        echo date('Y-m-d H:i:s', time()) . ' - Processed ' . $updateCount . ' updates';
    } else {
        echo date('Y-m-d H:i:s', time()) . ' - Failed to fetch updates' . PHP_EOL;
        echo $serverResponse->printError();
    }
} catch (Longman\TelegramBot\Exception\TelegramException $e) {
    echo $e;
    // Log telegram errors
    Longman\TelegramBot\TelegramLog::error($e);
} catch (\Longman\TelegramBot\Exception\TelegramException $e) {
    // Catch log initilization errors
    echo $e;
}
?>
<!--<meta http-equiv="refresh" content="1">-->
