<?php

namespace ErfanBot;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use Longman\TelegramBot\DB;
use Longman\TelegramBot\Request;
use Longman\TelegramBot\Telegram;
use PDO;

require "Config.php";

$telegram = new Telegram($token, $username);

$coins = getCoinsList();

foreach ($coins as $coin) {
    sendMessage($coin['name']);
}

/**
 * @param $coinName
 * @throws \Longman\TelegramBot\Exception\TelegramException
 */
function sendMessage($coinName)
{

    $data = [
        'chat_id' => "@BuyBitcoinChannel",
        'photo' => Request::encodeFile(__DIR__ . "/erfan.jpg"),
        'caption' => getMessageText(getCoinPrice($coinName),$coinName),
    ];
    Request::sendPhoto($data);
}

/**
 * @param $price
 * @param $coin
 * @return string
 */
function getMessageText($price,$coin)
{
    $text = " نام ارز :" . $coin . PHP_EOL;
    $text .= "قیمت جهانی :". getFaNumber(number_format($price,4)) . " دلار" . " (اعتبار ۵ دقیقه)" . PHP_EOL;
    $text .= "قیمت خرید از ما:  " . getFaNumber(number_format(getCommissionSalePrice($price))) . " تومان" . PHP_EOL;
    $text .= "قیمت فروش به ما:  " . getFaNumber(number_format(getCommissionBuyPrice($price))) . " تومان" . PHP_EOL;
    $text .= "جهت سفارش با ای دی زیر ارتباط برقرار کنید" . PHP_EOL;
    $text .= "@best_247" . PHP_EOL;
    return $text;
}

/**
 * @param $coinName
 * @return float|int
 */
function getCoinPrice($coinName)
{
    if (getCoinDetail($coinName) == null) {
        $price = getAlertSettingData()['dprice_bitcoin'];
    } else {
        $price = getCoinDetail($coinName)[0]['price_usd'];
    }
    return $price;
}

/**
 * @param $coinPrice
 * @return float|int
 */
function getCommissionSalePrice($coinPrice)
{
    $dollar = getAlertSettingData()['dollar_price'];
    $profitPercent = getAlertSettingData()['sale_profit_percent'];
    $stableProfit = getAlertSettingData()['sale_profit_stable'];
    return (($dollar * $coinPrice) * $profitPercent) + $stableProfit;
}

/**
 * @param $coinPrice
 * @return float|int
 */
function getCommissionBuyPrice($coinPrice)
{
    $dollar = getAlertSettingData()['dollar_price'];
    $profitPercent = getAlertSettingData()['buy_profit_percent'];
    $stableProfit = getAlertSettingData()['buy_profit_stable'];
    return (($dollar * $coinPrice) * $profitPercent) + $stableProfit;

}

/**
 * @param $coinName
 * @return mixed
 */
function getCoinDetail($coinName)
{
    try {
        $client = new Client();
        $res = $client->request('GET', "************************");
        $coinDetailAsJson = $res->getBody();
        $coinDetail = \GuzzleHttp\json_decode($coinDetailAsJson, true);
        return $coinDetail;
    } catch (ClientException $e) {
        echo 'Caught response: ' . $e->getResponse()->getStatusCode();
    }
}

/**
 * @param $number
 * @return mixed
 */
function    getFaNumber($number)
{
    $persian = array('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹');
    $num = range(0, 9);
    return str_replace($num, $persian, $number);
}

/**
 * @param $number
 * @return mixed
 */
function getEnNumber($number)
{
    $persian = array('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹');
    $num = range(0, 9);
    return str_replace($persian, $num, $number);
}

/**
 * @return mixed|null
 */
function getAlertSettingData()
{
    $pdo = DB::getPdo();
    $result = $pdo->query("SELECT * FROM alert_setting");
    if ($result->rowCount() == 0) {
        return null;
    }
    return $result->fetch(PDO::FETCH_ASSOC);
}

/**
 * @return array|null
 */
function getCoinsList()
{
    $pdo = DB::getPdo();
    $statment = $pdo->prepare("SELECT * FROM coins");
    $statment->execute();
    if ($statment->rowCount() == 0) {
        return null;
    }
    return $statment->fetchAll(PDO::FETCH_ASSOC);
}


