<?php

require './Config.php';

$hook_url = '***********************';
try {
    $result = $telegram->setWebhook($hook_url);
} catch (Longman\TelegramBot\Exception\TelegramException $e) {
    echo $e;
}
