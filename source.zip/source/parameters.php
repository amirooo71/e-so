<?php

$token = "******************";
$username = "*******************8";
$mysql_credentials = [
    'host' => 'localhost',
    'user' => '**************',
    'password' => '***********',
    'database' => '**********',
];

