<?php

require './Config.php';

try {
    $telegram->handle();
} catch (\Longman\TelegramBot\Exception\TelegramException $e) {

}
